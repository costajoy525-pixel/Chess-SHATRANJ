using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ShatranjChess
{
    public enum PieceColor { WHITE, BLACK }
    public enum PieceType { PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING }
    public enum MoveFlag { NORMAL, CASTLE_KINGSIDE, CASTLE_QUEENSIDE, EN_PASSANT, DOUBLE_PAWN_PUSH, PROMOTION_QUEEN, PROMOTION_ROOK, PROMOTION_BISHOP, PROMOTION_KNIGHT }
    public enum GameMode { VS_BOT, VS_PLAYER }
    public enum Difficulty { EASY, MEDIUM, HARD }
    public enum BoardTheme { NEUTRAL, BROWN, GREEN }

    public class Piece
    {
        public PieceColor Color;
        public PieceType Type;
        public Piece(PieceColor c, PieceType t) { Color = c; Type = t; }
    }

    public class Move
    {
        public int FromRow, FromCol, ToRow, ToCol;
        public MoveFlag Flag;
        public Move(int fr, int fc, int tr, int tc, MoveFlag flag = MoveFlag.NORMAL)
        {
            FromRow = fr; FromCol = fc; ToRow = tr; ToCol = tc; Flag = flag;
        }
        public bool IsPromotion()
        {
            return Flag == MoveFlag.PROMOTION_QUEEN || Flag == MoveFlag.PROMOTION_ROOK ||
                   Flag == MoveFlag.PROMOTION_BISHOP || Flag == MoveFlag.PROMOTION_KNIGHT;
        }
        public bool IsCastle()
        {
            return Flag == MoveFlag.CASTLE_KINGSIDE || Flag == MoveFlag.CASTLE_QUEENSIDE;
        }
    }

    public class MoveInfo
    {
        public Move Move;
        public Piece MovedPiece;
        public Piece CapturedPiece;
        public int PrevEpRow, PrevEpCol;
        public PieceColor PrevSide;
        public Piece CapturedEpPawn;
    }

    public class Board
    {
        public Piece[,] Squares = new Piece[8, 8];
        public PieceColor SideToMove = PieceColor.WHITE;
        public int EnPassantRow = -1, EnPassantCol = -1;

        public Board() { Reset(); }

        public void Reset()
        {
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                    Squares[r, c] = null;

            PieceType[] back = { PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN, PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK };
            for (int c = 0; c < 8; c++)
            {
                Squares[0, c] = new Piece(PieceColor.BLACK, back[c]);
                Squares[1, c] = new Piece(PieceColor.BLACK, PieceType.PAWN);
                Squares[6, c] = new Piece(PieceColor.WHITE, PieceType.PAWN);
                Squares[7, c] = new Piece(PieceColor.WHITE, back[c]);
            }
            SideToMove = PieceColor.WHITE;
            EnPassantRow = -1;
            EnPassantCol = -1;
        }

        public Piece GetPiece(int r, int c)
        {
            if (r < 0 || r > 7 || c < 0 || c > 7) return null;
            return Squares[r, c];
        }

        public MoveInfo MakeMove(Move m)
        {
            MoveInfo info = new MoveInfo
            {
                Move = m,
                MovedPiece = Squares[m.FromRow, m.FromCol],
                CapturedPiece = Squares[m.ToRow, m.ToCol],
                PrevEpRow = EnPassantRow,
                PrevEpCol = EnPassantCol,
                PrevSide = SideToMove
            };

            Squares[m.ToRow, m.ToCol] = info.MovedPiece;
            Squares[m.FromRow, m.FromCol] = null;

            if (m.Flag == MoveFlag.CASTLE_KINGSIDE)
            {
                Squares[m.FromRow, 5] = Squares[m.FromRow, 7];
                Squares[m.FromRow, 7] = null;
            }
            else if (m.Flag == MoveFlag.CASTLE_QUEENSIDE)
            {
                Squares[m.FromRow, 3] = Squares[m.FromRow, 0];
                Squares[m.FromRow, 0] = null;
            }
            else if (m.Flag == MoveFlag.EN_PASSANT)
            {
                info.CapturedEpPawn = Squares[m.FromRow, m.ToCol];
                Squares[m.FromRow, m.ToCol] = null;
            }

            if (m.IsPromotion())
            {
                PieceType pt = PieceType.QUEEN;
                if (m.Flag == MoveFlag.PROMOTION_ROOK) pt = PieceType.ROOK;
                else if (m.Flag == MoveFlag.PROMOTION_BISHOP) pt = PieceType.BISHOP;
                else if (m.Flag == MoveFlag.PROMOTION_KNIGHT) pt = PieceType.KNIGHT;
                Squares[m.ToRow, m.ToCol] = new Piece(info.MovedPiece.Color, pt);
            }

            EnPassantRow = -1;
            EnPassantCol = -1;
            if (m.Flag == MoveFlag.DOUBLE_PAWN_PUSH)
            {
                EnPassantRow = (m.FromRow + m.ToRow) / 2;
                EnPassantCol = m.FromCol;
            }

            SideToMove = (SideToMove == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
            return info;
        }

        public void UnmakeMove(MoveInfo info)
        {
            Move m = info.Move;
            Squares[m.FromRow, m.FromCol] = info.MovedPiece;
            Squares[m.ToRow, m.ToCol] = info.CapturedPiece;

            if (m.Flag == MoveFlag.CASTLE_KINGSIDE)
            {
                Squares[m.FromRow, 7] = Squares[m.FromRow, 5];
                Squares[m.FromRow, 5] = null;
            }
            else if (m.Flag == MoveFlag.CASTLE_QUEENSIDE)
            {
                Squares[m.FromRow, 0] = Squares[m.FromRow, 3];
                Squares[m.FromRow, 3] = null;
            }
            else if (m.Flag == MoveFlag.EN_PASSANT)
            {
                Squares[m.FromRow, m.ToCol] = info.CapturedEpPawn;
            }

            EnPassantRow = info.PrevEpRow;
            EnPassantCol = info.PrevEpCol;
            SideToMove = info.PrevSide;
        }

        public bool IsSquareAttacked(int row, int col, PieceColor byColor)
        {
            int pawnRow = (byColor == PieceColor.WHITE) ? row + 1 : row - 1;
            int[] dcs = { -1, 1 };
            foreach (int dc in dcs)
            {
                Piece p = GetPiece(pawnRow, col + dc);
                if (p != null && p.Color == byColor && p.Type == PieceType.PAWN) return true;
            }

            int[,] kOff = { { -2, -1 }, { -2, 1 }, { -1, -2 }, { -1, 2 }, { 1, -2 }, { 1, 2 }, { 2, -1 }, { 2, 1 } };
            for (int i = 0; i < 8; i++)
            {
                Piece p = GetPiece(row + kOff[i, 0], col + kOff[i, 1]);
                if (p != null && p.Color == byColor && p.Type == PieceType.KNIGHT) return true;
            }

            int[,] kingOff = { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, -1 }, { 0, 1 }, { 1, -1 }, { 1, 0 }, { 1, 1 } };
            for (int i = 0; i < 8; i++)
            {
                Piece p = GetPiece(row + kingOff[i, 0], col + kingOff[i, 1]);
                if (p != null && p.Color == byColor && p.Type == PieceType.KING) return true;
            }

            int[,] diag = { { -1, -1 }, { -1, 1 }, { 1, -1 }, { 1, 1 } };
            for (int i = 0; i < 4; i++)
            {
                int r = row + diag[i, 0], c = col + diag[i, 1];
                while (r >= 0 && r <= 7 && c >= 0 && c <= 7)
                {
                    Piece p = Squares[r, c];
                    if (p != null)
                    {
                        if (p.Color == byColor && (p.Type == PieceType.BISHOP || p.Type == PieceType.QUEEN)) return true;
                        break;
                    }
                    r += diag[i, 0]; c += diag[i, 1];
                }
            }

            int[,] str = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
            for (int i = 0; i < 4; i++)
            {
                int r = row + str[i, 0], c = col + str[i, 1];
                while (r >= 0 && r <= 7 && c >= 0 && c <= 7)
                {
                    Piece p = Squares[r, c];
                    if (p != null)
                    {
                        if (p.Color == byColor && (p.Type == PieceType.ROOK || p.Type == PieceType.QUEEN)) return true;
                        break;
                    }
                    r += str[i, 0]; c += str[i, 1];
                }
            }
            return false;
        }

        public bool IsInCheck(PieceColor color)
        {
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                {
                    Piece p = Squares[r, c];
                    if (p != null && p.Color == color && p.Type == PieceType.KING)
                    {
                        PieceColor opp = (color == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
                        return IsSquareAttacked(r, c, opp);
                    }
                }
            return false;
        }
    }

    public static class EngineAI
    {
        private static readonly int[,] PAWN_PST = {
            {  0,  0,  0,  0,  0,  0,  0,  0},
            { 50, 50, 50, 50, 50, 50, 50, 50},
            { 10, 10, 20, 30, 30, 20, 10, 10},
            {  5,  5, 10, 25, 25, 10,  5,  5},
            {  0,  0,  0, 20, 20,  0,  0,  0},
            {  5, -5,-10,  0,  0,-10, -5,  5},
            {  5, 10, 10,-20,-20, 10, 10,  5},
            {  0,  0,  0,  0,  0,  0,  0,  0}
        };
        private static readonly int[,] KNIGHT_PST = {
            {-50,-40,-30,-30,-30,-30,-40,-50},
            {-40,-20,  0,  0,  0,  0,-20,-40},
            {-30,  0, 10, 15, 15, 10,  0,-30},
            {-30,  5, 15, 20, 20, 15,  5,-30},
            {-30,  0, 15, 20, 20, 15,  0,-30},
            {-30,  5, 10, 15, 15, 10,  5,-30},
            {-40,-20,  0,  5,  5,  0,-20,-40},
            {-50,-40,-30,-30,-30,-30,-40,-50}
        };
        private static readonly int[,] BISHOP_PST = {
            {-20,-10,-10,-10,-10,-10,-10,-20},
            {-10,  0,  0,  0,  0,  0,  0,-10},
            {-10,  0,  5, 10, 10,  5,  0,-10},
            {-10,  5,  5, 10, 10,  5,  5,-10},
            {-10,  0, 10, 10, 10, 10,  0,-10},
            {-10, 10, 10, 10, 10, 10, 10,-10},
            {-10,  5,  0,  0,  0,  0,  5,-10},
            {-20,-10,-10,-10,-10,-10,-10,-20}
        };
        private static readonly int[,] ROOK_PST = {
            {  0,  0,  0,  0,  0,  0,  0,  0},
            {  5, 10, 10, 10, 10, 10, 10,  5},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            {  0,  0,  0,  5,  5,  0,  0,  0}
        };
        private static readonly int[,] QUEEN_PST = {
            {-20,-10,-10, -5, -5,-10,-10,-20},
            {-10,  0,  0,  0,  0,  0,  0,-10},
            {-10,  0,  5,  5,  5,  5,  0,-10},
            { -5,  0,  5,  5,  5,  5,  0, -5},
            {  0,  0,  5,  5,  5,  5,  0, -5},
            {-10,  5,  5,  5,  5,  5,  0,-10},
            {-10,  0,  5,  0,  0,  0,  0,-10},
            {-20,-10,-10, -5, -5,-10,-10,-20}
        };
        private static readonly int[,] KING_MID_PST = {
            {-30,-40,-40,-50,-50,-40,-40,-30},
            {-30,-40,-40,-50,-50,-40,-40,-30},
            {-30,-40,-40,-50,-50,-40,-40,-30},
            {-30,-40,-40,-50,-50,-40,-40,-30},
            {-20,-30,-30,-40,-40,-30,-30,-20},
            {-10,-20,-20,-20,-20,-20,-20,-10},
            { 20, 20,  0,  0,  0,  0, 20, 20},
            { 20, 30, 10,  0,  0, 10, 30, 20}
        };

        public static List<Move> GenerateLegalMoves(Board board)
        {
            List<Move> pseudo = GeneratePseudoMoves(board);
            List<Move> legal = new List<Move>();
            PieceColor mover = board.SideToMove;
            foreach (Move m in pseudo)
            {
                MoveInfo info = board.MakeMove(m);
                if (!board.IsInCheck(mover)) legal.Add(m);
                board.UnmakeMove(info);
            }
            return legal;
        }

        public static List<Move> GeneratePseudoMoves(Board board)
        {
            List<Move> moves = new List<Move>();
            PieceColor me = board.SideToMove;
            PieceColor opp = (me == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;

            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    Piece p = board.GetPiece(r, c);
                    if (p == null || p.Color != me) continue;

                    if (p.Type == PieceType.PAWN)
                    {
                        int dir = (me == PieceColor.WHITE) ? -1 : 1;
                        int startRow = (me == PieceColor.WHITE) ? 6 : 1;
                        int promoRow = (me == PieceColor.WHITE) ? 0 : 7;
                        int oneF = r + dir;
                        if (oneF >= 0 && oneF <= 7 && board.GetPiece(oneF, c) == null)
                        {
                            if (oneF == promoRow)
                            {
                                moves.Add(new Move(r, c, oneF, c, MoveFlag.PROMOTION_QUEEN));
                                moves.Add(new Move(r, c, oneF, c, MoveFlag.PROMOTION_ROOK));
                                moves.Add(new Move(r, c, oneF, c, MoveFlag.PROMOTION_BISHOP));
                                moves.Add(new Move(r, c, oneF, c, MoveFlag.PROMOTION_KNIGHT));
                            }
                            else moves.Add(new Move(r, c, oneF, c));

                            if (r == startRow && board.GetPiece(r + 2 * dir, c) == null)
                                moves.Add(new Move(r, c, r + 2 * dir, c, MoveFlag.DOUBLE_PAWN_PUSH));
                        }
                        int[] dcs = { -1, 1 };
                        foreach (int dc in dcs)
                        {
                            int tc = c + dc, tr = r + dir;
                            if (tc < 0 || tc > 7 || tr < 0 || tr > 7) continue;
                            Piece tgt = board.GetPiece(tr, tc);
                            if (tgt != null && tgt.Color != me)
                            {
                                if (tr == promoRow)
                                {
                                    moves.Add(new Move(r, c, tr, tc, MoveFlag.PROMOTION_QUEEN));
                                    moves.Add(new Move(r, c, tr, tc, MoveFlag.PROMOTION_ROOK));
                                    moves.Add(new Move(r, c, tr, tc, MoveFlag.PROMOTION_BISHOP));
                                    moves.Add(new Move(r, c, tr, tc, MoveFlag.PROMOTION_KNIGHT));
                                }
                                else moves.Add(new Move(r, c, tr, tc));
                            }
                            else if (tgt == null && tr == board.EnPassantRow && tc == board.EnPassantCol)
                            {
                                moves.Add(new Move(r, c, tr, tc, MoveFlag.EN_PASSANT));
                            }
                        }
                    }
                    else if (p.Type == PieceType.KNIGHT)
                    {
                        int[,] kOff = { { -2, -1 }, { -2, 1 }, { -1, -2 }, { -1, 2 }, { 1, -2 }, { 1, 2 }, { 2, -1 }, { 2, 1 } };
                        for (int i = 0; i < 8; i++)
                        {
                            int nr = r + kOff[i, 0], nc = c + kOff[i, 1];
                            if (nr < 0 || nr > 7 || nc < 0 || nc > 7) continue;
                            Piece tgt = board.GetPiece(nr, nc);
                            if (tgt == null || tgt.Color != me) moves.Add(new Move(r, c, nr, nc));
                        }
                    }
                    else if (p.Type == PieceType.BISHOP || p.Type == PieceType.ROOK || p.Type == PieceType.QUEEN)
                    {
                        int[,] dirs = { { -1, -1 }, { -1, 1 }, { 1, -1 }, { 1, 1 }, { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
                        int start = (p.Type == PieceType.ROOK) ? 4 : 0;
                        int end = (p.Type == PieceType.BISHOP) ? 4 : 8;
                        for (int i = start; i < end; i++)
                        {
                            int nr = r + dirs[i, 0], nc = c + dirs[i, 1];
                            while (nr >= 0 && nr <= 7 && nc >= 0 && nc <= 7)
                            {
                                Piece tgt = board.GetPiece(nr, nc);
                                if (tgt == null) moves.Add(new Move(r, c, nr, nc));
                                else
                                {
                                    if (tgt.Color != me) moves.Add(new Move(r, c, nr, nc));
                                    break;
                                }
                                nr += dirs[i, 0]; nc += dirs[i, 1];
                            }
                        }
                    }
                    else if (p.Type == PieceType.KING)
                    {
                        int[,] kingOff = { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, -1 }, { 0, 1 }, { 1, -1 }, { 1, 0 }, { 1, 1 } };
                        for (int i = 0; i < 8; i++)
                        {
                            int nr = r + kingOff[i, 0], nc = c + kingOff[i, 1];
                            if (nr < 0 || nr > 7 || nc < 0 || nc > 7) continue;
                            Piece tgt = board.GetPiece(nr, nc);
                            if (tgt == null || tgt.Color != me) moves.Add(new Move(r, c, nr, nc));
                        }
                        int crow = (me == PieceColor.WHITE) ? 7 : 0;
                        if (r == crow && c == 4)
                        {
                            Piece rk = board.GetPiece(crow, 7);
                            if (rk != null && rk.Type == PieceType.ROOK && rk.Color == me &&
                                board.GetPiece(crow, 5) == null && board.GetPiece(crow, 6) == null &&
                                !board.IsSquareAttacked(crow, 4, opp) && !board.IsSquareAttacked(crow, 5, opp) && !board.IsSquareAttacked(crow, 6, opp))
                            {
                                moves.Add(new Move(crow, 4, crow, 6, MoveFlag.CASTLE_KINGSIDE));
                            }
                            Piece rq = board.GetPiece(crow, 0);
                            if (rq != null && rq.Type == PieceType.ROOK && rq.Color == me &&
                                board.GetPiece(crow, 1) == null && board.GetPiece(crow, 2) == null && board.GetPiece(crow, 3) == null &&
                                !board.IsSquareAttacked(crow, 4, opp) && !board.IsSquareAttacked(crow, 3, opp) && !board.IsSquareAttacked(crow, 2, opp))
                            {
                                moves.Add(new Move(crow, 4, crow, 2, MoveFlag.CASTLE_QUEENSIDE));
                            }
                        }
                    }
                }
            }
            return moves;
        }

        private static int PieceValue(PieceType t)
        {
            switch (t)
            {
                case PieceType.PAWN: return 100;
                case PieceType.KNIGHT: return 320;
                case PieceType.BISHOP: return 330;
                case PieceType.ROOK: return 500;
                case PieceType.QUEEN: return 900;
                case PieceType.KING: return 20000;
                default: return 0;
            }
        }

        private static int PstValue(PieceType t, int row, int col, bool white)
        {
            int r = white ? row : (7 - row);
            int c = white ? col : (7 - col);
            switch (t)
            {
                case PieceType.PAWN: return PAWN_PST[r, c];
                case PieceType.KNIGHT: return KNIGHT_PST[r, c];
                case PieceType.BISHOP: return BISHOP_PST[r, c];
                case PieceType.ROOK: return ROOK_PST[r, c];
                case PieceType.QUEEN: return QUEEN_PST[r, c];
                case PieceType.KING: return KING_MID_PST[r, c];
                default: return 0;
            }
        }

        private static int Evaluate(Board board)
        {
            int wScore = 0, bScore = 0;
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                {
                    Piece p = board.GetPiece(r, c);
                    if (p == null) continue;
                    int val = PieceValue(p.Type) + PstValue(p.Type, r, c, p.Color == PieceColor.WHITE);
                    if (p.Color == PieceColor.WHITE) wScore += val;
                    else bScore += val;
                }
            return wScore - bScore;
        }

        private static int ScoreMove(Board board, Move m)
        {
            int s = 0;
            Piece v = board.GetPiece(m.ToRow, m.ToCol);
            Piece a = board.GetPiece(m.FromRow, m.FromCol);
            if (v != null && a != null) s += 10 * PieceValue(v.Type) - PieceValue(a.Type);
            if (m.IsPromotion()) s += 800;
            if (m.IsCastle()) s += 50;
            return s;
        }

        private static int Negamax(Board board, int depth, int alpha, int beta)
        {
            List<Move> moves = GenerateLegalMoves(board);
            if (moves.Count == 0)
            {
                if (board.IsInCheck(board.SideToMove)) return -100000 + (10 - depth);
                return 0;
            }
            if (depth == 0)
            {
                int ev = Evaluate(board);
                return (board.SideToMove == PieceColor.WHITE) ? ev : -ev;
            }
            moves.Sort((a, b) => ScoreMove(board, b) - ScoreMove(board, a));
            int best = -200000;
            foreach (Move m in moves)
            {
                MoveInfo info = board.MakeMove(m);
                int score = -Negamax(board, depth - 1, -beta, -alpha);
                board.UnmakeMove(info);
                if (score > best) best = score;
                if (score > alpha) alpha = score;
                if (alpha >= beta) break;
            }
            return best;
        }

        public static Move FindBestMove(Board board, int depth)
        {
            List<Move> moves = GenerateLegalMoves(board);
            if (moves.Count == 0) return null;
            if (moves.Count == 1) return moves[0];
            moves.Sort((a, b) => ScoreMove(board, b) - ScoreMove(board, a));
            Move bestMove = moves[0];
            int bestScore = -200000, alpha = -200000, beta = 200000;
            foreach (Move m in moves)
            {
                MoveInfo info = board.MakeMove(m);
                int score = -Negamax(board, depth - 1, -beta, -alpha);
                board.UnmakeMove(info);
                if (score > bestScore) { bestScore = score; bestMove = m; }
                if (score > alpha) alpha = score;
            }
            return bestMove;
        }
    }

    public class MainForm : Form
    {
        private Board board = new Board();
        private List<MoveInfo> history = new List<MoveInfo>();
        private List<string> moveNotation = new List<string>();
        private GameMode mode = GameMode.VS_BOT;
        private Difficulty difficulty = Difficulty.MEDIUM;
        private PieceColor humanColor = PieceColor.WHITE;
        private BoardTheme theme = BoardTheme.NEUTRAL;

        private int startingTime = 180;
        private int whiteTime = 180, blackTime = 180;
        private bool clockRunning = false, gameOver = false;
        private bool showingStartScreen = true, paused = true, drawerOpen = false, showGameOverPopup = false, botThinking = false;
        private bool boardFlipped = false;

        private int selectedRow = -1, selectedCol = -1;
        private int lastMovedRow = -1, lastMovedCol = -1;
        private bool premoveEnabled = false;
        private int premoveFromRow = -1, premoveFromCol = -1, premoveToRow = -1, premoveToCol = -1;
        private int movesScrollOffset = 0;

        private bool modeExpanded = true, gameExpanded = true, timeExpanded = true, themeExpanded = true;
        private string popupTitle = "CHECKMATE", popupMsg = "White wins!", popupTime = "";

        private List< Tuple<Rectangle, Action> > clickRegions = new List< Tuple<Rectangle, Action> >();
        private Timer clockTimer;

        public MainForm()
        {
            Text = "Chess - Shatranj by Group 1";
            ClientSize = new Size(1160, 800);
            MinimumSize = new Size(1000, 760);
            StartPosition = FormStartPosition.CenterScreen;
            DoubleBuffered = true;
            BackColor = Color.FromArgb(30, 30, 30);

            try
            {
                string icoPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app\\Shatranj.ico");
                if (System.IO.File.Exists(icoPath)) Icon = new Icon(icoPath);
            }
            catch { }

            clockTimer = new Timer { Interval = 1000 };
            clockTimer.Tick += (s, e) =>
            {
                if (showingStartScreen || paused || !clockRunning || gameOver) return;
                if (board.SideToMove == PieceColor.WHITE)
                {
                    whiteTime--;
                    if (whiteTime <= 0) { whiteTime = 0; TriggerGameOver(); }
                }
                else
                {
                    blackTime--;
                    if (blackTime <= 0) { blackTime = 0; TriggerGameOver(); }
                }
                Invalidate();
            };
            clockTimer.Start();

            MouseDown += OnCanvasMouseDown;
            MouseWheel += (s, e) =>
            {
                if (e.Delta < 0) movesScrollOffset = Math.Min(Math.Max(0, (moveNotation.Count + 1) / 2 - 6), movesScrollOffset + 1);
                else movesScrollOffset = Math.Max(0, movesScrollOffset - 1);
                Invalidate();
            };
            Resize += (s, e) => Invalidate();
        }

        private void AddHit(Rectangle r, Action a)
        {
            clickRegions.Add(new Tuple<Rectangle, Action>(r, a));
        }

        private void StartNewGame(PieceColor color)
        {
            humanColor = color;
            board.Reset();
            history.Clear();
            moveNotation.Clear();
            whiteTime = startingTime;
            blackTime = startingTime;
            clockRunning = false;
            gameOver = false;
            showGameOverPopup = false;
            paused = false;
            botThinking = false;
            boardFlipped = (mode == GameMode.VS_BOT && color == PieceColor.BLACK);
            selectedRow = -1; selectedCol = -1;
            lastMovedRow = -1; lastMovedCol = -1;
            premoveFromRow = -1; premoveFromCol = -1; premoveToRow = -1; premoveToCol = -1;
            movesScrollOffset = 0;
            Invalidate();

            if (mode == GameMode.VS_BOT && board.SideToMove != humanColor)
                StartBotTurn();
        }

        private void StartBotTurn()
        {
            botThinking = true;
            Invalidate();
            Timer botTimer = new Timer { Interval = 550 };
            botTimer.Tick += (s, e) =>
            {
                botTimer.Stop();
                botTimer.Dispose();
                int depth = (difficulty == Difficulty.EASY) ? 1 : (difficulty == Difficulty.HARD ? 3 : 2);
                Move bm = EngineAI.FindBestMove(board, depth);
                if (bm != null)
                {
                    ExecuteMove(bm);
                }
                botThinking = false;
                Invalidate();
                if (!gameOver && mode == GameMode.VS_BOT && board.SideToMove == humanColor && premoveFromRow != -1 && premoveToRow != -1)
                {
                    Move pm = FindLegalMove(premoveFromRow, premoveFromCol, premoveToRow, premoveToCol);
                    premoveFromRow = -1; premoveFromCol = -1; premoveToRow = -1; premoveToCol = -1;
                    if (pm != null)
                    {
                        ExecuteMove(pm);
                        if (!gameOver && mode == GameMode.VS_BOT) StartBotTurn();
                    }
                    Invalidate();
                }
            };
            botTimer.Start();
        }

        private void ExecuteMove(Move m)
        {
            Piece mp = board.GetPiece(m.FromRow, m.FromCol);
            Piece cp = board.GetPiece(m.ToRow, m.ToCol);
            if (m.Flag == MoveFlag.EN_PASSANT) cp = board.GetPiece(m.FromRow, m.ToCol);
            string not = ToAlgebraic(m, mp, cp);
            MoveInfo info = board.MakeMove(m);
            history.Add(info);
            moveNotation.Add(not);
            lastMovedRow = m.ToRow;
            lastMovedCol = m.ToCol;
            clockRunning = true;

            List<Move> legal = EngineAI.GenerateLegalMoves(board);
            if (legal.Count == 0)
            {
                if (board.IsInCheck(board.SideToMove))
                    moveNotation[moveNotation.Count - 1] += "#";
                TriggerGameOver();
            }
            else if (board.IsInCheck(board.SideToMove))
            {
                moveNotation[moveNotation.Count - 1] += "+";
            }
            movesScrollOffset = Math.Max(0, (moveNotation.Count + 1) / 2 - 6);
        }

        private void TriggerGameOver()
        {
            gameOver = true;
            clockRunning = false;
            showGameOverPopup = true;
            if (whiteTime <= 0) { popupTitle = "TIME OUT"; popupMsg = "Black wins on time!"; }
            else if (blackTime <= 0) { popupTitle = "TIME OUT"; popupMsg = "White wins on time!"; }
            else if (board.IsInCheck(board.SideToMove))
            {
                popupTitle = "CHECKMATE";
                popupMsg = (board.SideToMove == PieceColor.WHITE ? "Black" : "White") + " wins!";
            }
            else
            {
                popupTitle = "STALEMATE";
                popupMsg = "It's a draw.";
            }
            popupTime = "Time used — White: " + FormatTime(startingTime - whiteTime) + "   Black: " + FormatTime(startingTime - blackTime);
        }

        private string ToAlgebraic(Move m, Piece mp, Piece cp)
        {
            if (m.IsCastle()) return m.Flag == MoveFlag.CASTLE_KINGSIDE ? "O-O" : "O-O-O";
            string s = "";
            if (mp.Type == PieceType.KING) s += "K";
            else if (mp.Type == PieceType.QUEEN) s += "Q";
            else if (mp.Type == PieceType.ROOK) s += "R";
            else if (mp.Type == PieceType.BISHOP) s += "B";
            else if (mp.Type == PieceType.KNIGHT) s += "N";
            if (mp.Type == PieceType.PAWN && cp != null) s += (char)('a' + m.FromCol);
            if (cp != null) s += "x";
            s += (char)('a' + m.ToCol);
            s += (char)('1' + (7 - m.ToRow));
            if (m.IsPromotion()) s += "=Q";
            return s;
        }

        private Move FindLegalMove(int fr, int fc, int tr, int tc)
        {
            List<Move> legal = EngineAI.GenerateLegalMoves(board);
            Move fb = null;
            foreach (Move m in legal)
            {
                if (m.FromRow == fr && m.FromCol == fc && m.ToRow == tr && m.ToCol == tc)
                {
                    if (m.Flag == MoveFlag.PROMOTION_QUEEN) return m;
                    if (fb == null) fb = m;
                }
            }
            return fb;
        }

        private void OnBoardCellClick(int dr, int dc)
        {
            if (showingStartScreen || gameOver || paused || drawerOpen) return;
            int r = boardFlipped ? 7 - dr : dr;
            int c = boardFlipped ? 7 - dc : dc;

            bool humanTurn = (mode == GameMode.VS_PLAYER) || (board.SideToMove == humanColor);
            if (!humanTurn && !premoveEnabled) return;
            if (!humanTurn && premoveEnabled)
            {
                Piece cl = board.GetPiece(r, c);
                if (premoveFromRow == -1)
                {
                    if (cl != null && cl.Color == humanColor) { premoveFromRow = r; premoveFromCol = c; Invalidate(); }
                    return;
                }
                if (cl != null && cl.Color == humanColor && !(r == premoveFromRow && c == premoveFromCol))
                {
                    premoveFromRow = r; premoveFromCol = c; premoveToRow = -1; premoveToCol = -1; Invalidate();
                    return;
                }
                premoveToRow = r; premoveToCol = c; Invalidate();
                return;
            }
            if (botThinking) return;

            Piece clicked = board.GetPiece(r, c);
            if (selectedRow == -1)
            {
                if (clicked != null && clicked.Color == board.SideToMove)
                {
                    selectedRow = r; selectedCol = c; Invalidate();
                }
                return;
            }

            Move chosen = FindLegalMove(selectedRow, selectedCol, r, c);
            if (chosen != null)
            {
                selectedRow = -1; selectedCol = -1;
                ExecuteMove(chosen);
                Invalidate();
                if (!gameOver && mode == GameMode.VS_BOT) StartBotTurn();
            }
            else
            {
                if (clicked != null && clicked.Color == board.SideToMove) { selectedRow = r; selectedCol = c; }
                else { selectedRow = -1; selectedCol = -1; }
                Invalidate();
            }
        }

        private void OnCanvasMouseDown(object sender, MouseEventArgs e)
        {
            for (int i = clickRegions.Count - 1; i >= 0; i--)
            {
                if (clickRegions[i].Item1.Contains(e.Location))
                {
                    Action act = clickRegions[i].Item2;
                    act();
                    return;
                }
            }
        }

        private string FormatTime(int s)
        {
            int m = Math.Max(0, s) / 60;
            int sec = Math.Max(0, s) % 60;
            return string.Format("{0:00}:{1:00}", m, sec);
        }

        private string GetCapturedPieces(PieceColor color)
        {
            int p = 0, n = 0, b = 0, r = 0, q = 0;
            for (int row = 0; row < 8; row++)
                for (int col = 0; col < 8; col++)
                {
                    Piece pc = board.GetPiece(row, col);
                    if (pc != null && pc.Color == color)
                    {
                        if (pc.Type == PieceType.PAWN) p++;
                        else if (pc.Type == PieceType.KNIGHT) n++;
                        else if (pc.Type == PieceType.BISHOP) b++;
                        else if (pc.Type == PieceType.ROOK) r++;
                        else if (pc.Type == PieceType.QUEEN) q++;
                    }
                }
            List<string> list = new List<string>();
            for (int i = p; i < 8; i++) list.Add("\u265F");
            for (int i = n; i < 2; i++) list.Add("\u265E");
            for (int i = b; i < 2; i++) list.Add("\u265D");
            for (int i = r; i < 2; i++) list.Add("\u265C");
            for (int i = q; i < 1; i++) list.Add("\u265B");
            return list.Count == 0 ? "None" : string.Join(" ", list);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            clickRegions.Clear();

            int W = ClientSize.Width;
            int H = ClientSize.Height;

            if (showingStartScreen)
            {
                DrawStartScreen(g, W, H);
                return;
            }

            // Top Bar
            Rectangle hamRect = new Rectangle(24, 16, 48, 38);
            DrawButton(g, hamRect, "\u2630", Color.FromArgb(38, 36, 33), Color.White, 16f);
            AddHit(hamRect, () => { drawerOpen = !drawerOpen; Invalidate(); });

            using (Font fTitle = new Font("Segoe UI", 16f, FontStyle.Bold))
            using (Font fSub = new Font("Segoe UI", 11f, FontStyle.Italic))
            using (Brush bWhite = new SolidBrush(Color.FromArgb(232, 232, 232)))
            using (Brush bGreen = new SolidBrush(Color.FromArgb(129, 182, 76)))
            {
                g.DrawString("Shatranj", fTitle, bWhite, 84, 19);
                g.DrawString("by Group 1", fSub, bGreen, 182, 24);
            }

            // Center layout
            int contentW = 664 + 24 + 230;
            int startX = Math.Max(24, (W - contentW) / 2);
            int startY = 66;

            // Board Frame
            Rectangle boardFrame = new Rectangle(startX, startY, 664, 664);
            FillRoundRect(g, boardFrame, Color.FromArgb(49, 46, 43), 12);

            int bx = startX + 12;
            int by = startY + 12;
            List<Move> legalMoves = (selectedRow != -1) ? EngineAI.GenerateLegalMoves(board) : new List<Move>();

            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    int dr = boardFlipped ? 7 - r : r;
                    int dc = boardFlipped ? 7 - c : c;
                    Rectangle cellRect = new Rectangle(bx + dc * 80, by + dr * 80, 80, 80);

                    Color sqColor = ((r + c) % 2 == 0) ? GetLightColor() : GetDarkColor();
                    if (r == selectedRow && c == selectedCol) sqColor = Color.FromArgb(247, 215, 116);
                    else if ((r == premoveFromRow && c == premoveFromCol) || (r == premoveToRow && c == premoveToCol))
                        sqColor = Color.FromArgb(196, 181, 224);

                    using (Brush sb = new SolidBrush(sqColor)) g.FillRectangle(sb, cellRect);

                    if (r == lastMovedRow && c == lastMovedCol)
                    {
                        using (Pen p = new Pen(Color.FromArgb(136, 136, 136), 3f))
                        {
                            p.DashPattern = new float[] { 3f, 2f };
                            g.DrawRectangle(p, cellRect.X + 2, cellRect.Y + 2, 76, 76);
                        }
                    }

                    bool isDest = false;
                    foreach (Move m in legalMoves)
                        if (m.FromRow == selectedRow && m.FromCol == selectedCol && m.ToRow == r && m.ToCol == c)
                        { isDest = true; break; }

                    Piece pOnSq = board.GetPiece(r, c);
                    if (isDest && pOnSq == null)
                    {
                        using (Brush db = new SolidBrush(Color.FromArgb(140, 58, 58, 58)))
                            g.FillEllipse(db, cellRect.X + 32, cellRect.Y + 32, 16, 16);
                    }
                    else if (isDest && pOnSq != null)
                    {
                        using (Pen dp = new Pen(Color.FromArgb(155, 58, 58, 58), 4f))
                            g.DrawEllipse(dp, cellRect.X + 10, cellRect.Y + 10, 60, 60);
                    }

                    if (pOnSq != null)
                    {
                        string sym = GetPieceSymbol(pOnSq);
                        using (Font pf = new Font("Segoe UI Symbol", 40f, FontStyle.Regular))
                        using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                        {
                            g.DrawString(sym, pf, Brushes.Black, cellRect, sf);
                        }
                    }

                    int clickDr = dr, clickDc = dc;
                    if (!drawerOpen && !showGameOverPopup)
                        AddHit(cellRect, () => OnBoardCellClick(clickDr, clickDc));
                }
            }

            // Right Sidebar
            int sx = startX + 664 + 24;
            int sy = startY;
            int sw = 230;

            bool premoveLocked = moveNotation.Count > 0;
            Rectangle pmRect = new Rectangle(sx, sy, sw, 42);
            Color pmBg = premoveLocked ? Color.FromArgb(42, 42, 42) : (premoveEnabled ? Color.FromArgb(129, 182, 76) : Color.FromArgb(58, 58, 58));
            DrawButton(g, pmRect, "Premove: " + (premoveEnabled ? "ON" : "OFF"), pmBg, Color.White, 11f);
            if (!premoveLocked && !drawerOpen && !showGameOverPopup)
                AddHit(pmRect, () => { premoveEnabled = !premoveEnabled; Invalidate(); });
            sy += 52;

            // Black Clock Card
            Rectangle bClockCard = new Rectangle(sx, sy, sw, 78);
            FillRoundRect(g, bClockCard, Color.FromArgb(38, 36, 33), 10);
            DrawCardLabel(g, "BLACK", sx + 12, sy + 10);
            DrawClockValue(g, FormatTime(blackTime), sx + 12, sy + 28, board.SideToMove == PieceColor.BLACK && !gameOver);
            sy += 88;

            // White Clock Card
            Rectangle wClockCard = new Rectangle(sx, sy, sw, 78);
            FillRoundRect(g, wClockCard, Color.FromArgb(38, 36, 33), 10);
            DrawCardLabel(g, "WHITE", sx + 12, sy + 10);
            DrawClockValue(g, FormatTime(whiteTime), sx + 12, sy + 28, board.SideToMove == PieceColor.WHITE && !gameOver);
            sy += 88;

            // Captured Pieces Card
            Rectangle capCard = new Rectangle(sx, sy, sw, 112);
            FillRoundRect(g, capCard, Color.FromArgb(38, 36, 33), 10);
            DrawCardLabel(g, "CAPTURED PIECES", sx + 12, sy + 10);
            using (Font fSub = new Font("Segoe UI", 9f))
            using (Font fSym = new Font("Segoe UI Symbol", 12f))
            using (Brush bLight = new SolidBrush(Color.FromArgb(232, 232, 232)))
            {
                g.DrawString("White captured:", fSub, bLight, sx + 12, sy + 28);
                g.DrawString(GetCapturedPieces(PieceColor.WHITE), fSym, Brushes.White, new RectangleF(sx + 12, sy + 44, sw - 20, 22));
                g.DrawString("Black captured:", fSub, bLight, sx + 12, sy + 68);
                g.DrawString(GetCapturedPieces(PieceColor.BLACK), fSym, Brushes.White, new RectangleF(sx + 12, sy + 84, sw - 20, 22));
            }
            sy += 122;

            // Play As Card
            Rectangle playCard = new Rectangle(sx, sy, sw, 74);
            FillRoundRect(g, playCard, Color.FromArgb(38, 36, 33), 10);
            DrawCardLabel(g, "PLAY AS", sx + 12, sy + 10);
            Rectangle pwRect = new Rectangle(sx + 12, sy + 30, (sw - 30) / 2, 34);
            Rectangle pbRect = new Rectangle(sx + 18 + (sw - 30) / 2, sy + 30, (sw - 30) / 2, 34);
            bool pvp = (mode == GameMode.VS_PLAYER);
            DrawButton(g, pwRect, "White", Color.FromArgb(58, 58, 58), pvp ? Color.Gray : Color.White, 10f);
            DrawButton(g, pbRect, "Black", Color.FromArgb(58, 58, 58), pvp ? Color.Gray : Color.White, 10f);
            if (!pvp && !drawerOpen && !showGameOverPopup)
            {
                AddHit(pwRect, () => StartNewGame(PieceColor.WHITE));
                AddHit(pbRect, () => StartNewGame(PieceColor.BLACK));
            }
            sy += 84;

            // Undo Button
            bool canUndo = !botThinking && !gameOver && !paused && moveNotation.Count >= 2;
            Rectangle undoRect = new Rectangle(sx, sy, sw, 42);
            DrawButton(g, undoRect, "Undo Last Move",
                canUndo ? Color.FromArgb(209, 124, 74) : Color.FromArgb(58, 58, 58),
                canUndo ? Color.White : Color.FromArgb(106, 106, 106), 11f);
            if (canUndo && !drawerOpen && !showGameOverPopup)
            {
                AddHit(undoRect, () =>
                {
                    for (int k = 0; k < 2 && history.Count > 0; k++)
                    {
                        board.UnmakeMove(history[history.Count - 1]);
                        history.RemoveAt(history.Count - 1);
                        moveNotation.RemoveAt(moveNotation.Count - 1);
                    }
                    selectedRow = -1; selectedCol = -1; lastMovedRow = -1; lastMovedCol = -1;
                    Invalidate();
                });
            }
            sy += 52;

            // Moves Card
            int movesH = Math.Max(80, startY + 664 - sy);
            Rectangle movesCard = new Rectangle(sx, sy, sw, movesH);
            FillRoundRect(g, movesCard, Color.FromArgb(38, 36, 33), 10);
            DrawCardLabel(g, "MOVES", sx + 12, sy + 10);
            using (Font mf = new Font("Segoe UI", 9.5f, FontStyle.Bold))
            using (Brush mb = new SolidBrush(Color.FromArgb(154, 154, 154)))
            {
                int my = sy + 30;
                int totalLines = (moveNotation.Count + 1) / 2;
                for (int lineIdx = movesScrollOffset; lineIdx < totalLines && my + 18 <= sy + movesH - 6; lineIdx++)
                {
                    int i = lineIdx * 2;
                    string line = (lineIdx + 1) + ". " + moveNotation[i];
                    if (i + 1 < moveNotation.Count) line += "   " + moveNotation[i + 1];
                    g.DrawString(line, mf, mb, sx + 12, my);
                    my += 18;
                }
            }

            // Bottom Status Label
            string statusText = "White to move";
            if (paused) statusText = "Paused";
            else if (botThinking) statusText = (premoveFromRow != -1 && premoveToRow != -1) ? "Bot is thinking... (Premove queued)" : "Bot is thinking...";
            else
            {
                string chk = board.IsInCheck(board.SideToMove) ? " (CHECK!)" : "";
                statusText = (board.SideToMove == PieceColor.WHITE ? "White" : "Black") + " to move" + chk;
            }
            using (Font sfFont = new Font("Segoe UI", 12f))
            using (Brush sb = new SolidBrush(Color.FromArgb(232, 232, 232)))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center })
            {
                g.DrawString(statusText, sfFont, sb, new RectangleF(0, startY + 676, W, 30), sf);
            }

            if (drawerOpen) DrawDrawerOverlay(g, W, H);
            if (showGameOverPopup) DrawGameOverPopup(g, W, H);
        }

        private void DrawStartScreen(Graphics g, int W, int H)
        {
            using (Font kf = new Font("Segoe UI Symbol", 160f))
            using (Brush kb = new SolidBrush(Color.FromArgb(38, 36, 33)))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                g.DrawString("\u2658", kf, kb, new RectangleF(W / 2 - 470, H / 2 - 200, 240, 340), sf);
                g.DrawString("\u265E", kf, kb, new RectangleF(W / 2 + 230, H / 2 - 200, 240, 340), sf);
            }

            using (Font tf = new Font("Segoe UI", 38f, FontStyle.Bold))
            using (Font subf = new Font("Segoe UI", 15f, FontStyle.Italic))
            using (Brush tb = new SolidBrush(Color.FromArgb(245, 197, 66)))
            using (Brush subb = new SolidBrush(Color.FromArgb(129, 182, 76)))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center })
            {
                g.DrawString("SHATRANJ", tf, tb, new RectangleF(W / 2 - 200, H / 2 - 170, 400, 65), sf);
                g.DrawString("by Group 1", subf, subb, new RectangleF(W / 2 - 200, H / 2 - 102, 400, 35), sf);
            }

            int bw = 360, bh = 50, bx = (W - bw) / 2, by = H / 2 - 40;
            Rectangle startRect = new Rectangle(bx, by, bw, bh);
            DrawButton(g, startRect, "Start Game", Color.FromArgb(129, 182, 76), Color.White, 13f);
            AddHit(startRect, () =>
            {
                showingStartScreen = false;
                StartNewGame(humanColor);
            });

            bool canContinue = gameOver || moveNotation.Count > 0;
            Rectangle contRect = new Rectangle(bx, by + 65, bw, bh);
            DrawButton(g, contRect, "Continue", Color.FromArgb(58, 58, 58),
                canContinue ? Color.White : Color.FromArgb(106, 106, 106), 13f);
            if (canContinue)
            {
                AddHit(contRect, () =>
                {
                    showingStartScreen = false;
                    paused = false;
                    Invalidate();
                });
            }

            Rectangle quitRect = new Rectangle(bx, by + 130, bw, bh);
            DrawButton(g, quitRect, "Quit", Color.FromArgb(192, 82, 66), Color.White, 13f);
            AddHit(quitRect, () => Application.Exit());
        }

        private void DrawDrawerOverlay(Graphics g, int W, int H)
        {
            using (Brush dim = new SolidBrush(Color.FromArgb(130, 0, 0, 0)))
                g.FillRectangle(dim, 0, 0, W, H);

            AddHit(new Rectangle(320, 0, W - 320, H), () => { drawerOpen = false; Invalidate(); });

            using (Brush db = new SolidBrush(Color.FromArgb(38, 36, 33)))
                g.FillRectangle(db, 0, 0, 320, H);

            int x = 24, y = 24, w = 272;

            // GAME MODE
            Rectangle gmHdr = new Rectangle(x, y, w, 36);
            DrawSectionHeader(g, gmHdr, (modeExpanded ? "\u25BC  " : "\u25B6  ") + "GAME MODE");
            AddHit(gmHdr, () => { modeExpanded = !modeExpanded; Invalidate(); });
            y += 44;
            if (modeExpanded)
            {
                Rectangle botRect = new Rectangle(x, y, w, 40);
                DrawButton(g, botRect, "Player vs Bot", mode == GameMode.VS_BOT ? Color.FromArgb(129, 182, 76) : Color.FromArgb(58, 58, 58), Color.White, 10.5f);
                AddHit(botRect, () => { mode = GameMode.VS_BOT; StartNewGame(humanColor); });
                y += 46;

                if (mode == GameMode.VS_BOT)
                {
                    int dw = (w - 12) / 3;
                    Difficulty[] diffs = { Difficulty.EASY, Difficulty.MEDIUM, Difficulty.HARD };
                    string[] dNames = { "Easy", "Medium", "Hard" };
                    for (int i = 0; i < 3; i++)
                    {
                        Difficulty dVal = diffs[i];
                        Rectangle dr = new Rectangle(x + i * (dw + 6), y, dw, 32);
                        DrawButton(g, dr, dNames[i], difficulty == dVal ? Color.FromArgb(129, 182, 76) : Color.FromArgb(58, 58, 58), Color.White, 9f);
                        AddHit(dr, () => { difficulty = dVal; drawerOpen = false; StartNewGame(humanColor); });
                    }
                    y += 40;
                }

                Rectangle pvpRect = new Rectangle(x, y, w, 40);
                DrawButton(g, pvpRect, "Player vs Player", mode == GameMode.VS_PLAYER ? Color.FromArgb(129, 182, 76) : Color.FromArgb(58, 58, 58), Color.White, 10.5f);
                AddHit(pvpRect, () => { mode = GameMode.VS_PLAYER; drawerOpen = false; StartNewGame(humanColor); });
                y += 48;
            }

            // GAME
            Rectangle gHdr = new Rectangle(x, y, w, 36);
            DrawSectionHeader(g, gHdr, (gameExpanded ? "\u25BC  " : "\u25B6  ") + "GAME");
            AddHit(gHdr, () => { gameExpanded = !gameExpanded; Invalidate(); });
            y += 44;
            if (gameExpanded)
            {
                Rectangle ngRect = new Rectangle(x, y, w, 40);
                DrawButton(g, ngRect, "New Game", Color.FromArgb(58, 58, 58), Color.White, 10.5f);
                AddHit(ngRect, () => { drawerOpen = false; StartNewGame(humanColor); });
                y += 46;

                Rectangle psRect = new Rectangle(x, y, w, 40);
                DrawButton(g, psRect, paused ? "Resume" : "Pause", Color.FromArgb(58, 58, 58), Color.White, 10.5f);
                AddHit(psRect, () => { paused = !paused; drawerOpen = false; Invalidate(); });
                y += 46;

                Rectangle qmRect = new Rectangle(x, y, w, 40);
                DrawButton(g, qmRect, "Quit to Menu", Color.FromArgb(192, 82, 66), Color.White, 10.5f);
                AddHit(qmRect, () => { drawerOpen = false; paused = true; showingStartScreen = true; Invalidate(); });
                y += 48;
            }

            // TIME CONTROL
            Rectangle tcHdr = new Rectangle(x, y, w, 36);
            DrawSectionHeader(g, tcHdr, (timeExpanded ? "\u25BC  " : "\u25B6  ") + "TIME CONTROL");
            AddHit(tcHdr, () => { timeExpanded = !timeExpanded; Invalidate(); });
            y += 44;
            if (timeExpanded)
            {
                int tw = (w - 6) / 2;
                int[] secs = { 60, 180, 600, 1800 };
                string[] tNames = { "Bullet", "Blitz", "Rapid", "Classic" };
                for (int i = 0; i < 4; i++)
                {
                    int sVal = secs[i];
                    Rectangle tr = new Rectangle(x + (i % 2) * (tw + 6), y + (i / 2) * 38, tw, 32);
                    DrawButton(g, tr, tNames[i], startingTime == sVal ? Color.FromArgb(129, 182, 76) : Color.FromArgb(58, 58, 58), Color.White, 9f);
                    AddHit(tr, () => { startingTime = sVal; drawerOpen = false; StartNewGame(humanColor); });
                }
                y += 82;
            }

            // THEME
            Rectangle thHdr = new Rectangle(x, y, w, 36);
            DrawSectionHeader(g, thHdr, (themeExpanded ? "\u25BC  " : "\u25B6  ") + "THEME");
            AddHit(thHdr, () => { themeExpanded = !themeExpanded; Invalidate(); });
            y += 44;
            if (themeExpanded)
            {
                int thw = (w - 12) / 3;
                BoardTheme[] ths = { BoardTheme.NEUTRAL, BoardTheme.BROWN, BoardTheme.GREEN };
                string[] thNames = { "Neutral", "Brown", "Green" };
                for (int i = 0; i < 3; i++)
                {
                    BoardTheme tVal = ths[i];
                    Rectangle thr = new Rectangle(x + i * (thw + 6), y, thw, 32);
                    DrawButton(g, thr, thNames[i], theme == tVal ? Color.FromArgb(129, 182, 76) : Color.FromArgb(58, 58, 58), Color.White, 9f);
                    AddHit(thr, () => { theme = tVal; drawerOpen = false; Invalidate(); });
                }
                y += 42;
            }

            Rectangle closeRect = new Rectangle(x, y + 6, w, 40);
            DrawButton(g, closeRect, "Close", Color.FromArgb(58, 58, 58), Color.White, 10.5f);
            AddHit(closeRect, () => { drawerOpen = false; Invalidate(); });
        }

        private void DrawGameOverPopup(Graphics g, int W, int H)
        {
            using (Brush dim = new SolidBrush(Color.FromArgb(165, 0, 0, 0)))
                g.FillRectangle(dim, 0, 0, W, H);

            int cw = 360, ch = 320, cx = (W - cw) / 2, cy = (H - ch) / 2;
            Rectangle card = new Rectangle(cx, cy, cw, ch);
            FillRoundRect(g, card, Color.FromArgb(49, 46, 43), 14);

            using (Font tf = new Font("Segoe UI", 20f, FontStyle.Bold))
            using (Font mf = new Font("Segoe UI", 13f))
            using (Font tmf = new Font("Segoe UI", 9f))
            using (Brush tb = new SolidBrush(Color.FromArgb(245, 197, 66)))
            using (Brush mb = new SolidBrush(Color.FromArgb(232, 232, 232)))
            using (Brush tmb = new SolidBrush(Color.FromArgb(154, 154, 154)))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center })
            {
                g.DrawString(popupTitle, tf, tb, new RectangleF(cx, cy + 26, cw, 36), sf);
                g.DrawString(popupMsg, mf, mb, new RectangleF(cx, cy + 68, cw, 28), sf);
                g.DrawString(popupTime, tmf, tmb, new RectangleF(cx, cy + 100, cw, 22), sf);
            }

            Rectangle ngRect = new Rectangle(cx + 44, cy + 136, cw - 88, 42);
            DrawButton(g, ngRect, "New Game", Color.FromArgb(129, 182, 76), Color.White, 11f);
            AddHit(ngRect, () => { showGameOverPopup = false; StartNewGame(humanColor); });

            Rectangle vbRect = new Rectangle(cx + 44, cy + 188, cw - 88, 42);
            DrawButton(g, vbRect, "View Board", Color.FromArgb(58, 58, 58), Color.White, 11f);
            AddHit(vbRect, () => { showGameOverPopup = false; Invalidate(); });

            Rectangle qmRect = new Rectangle(cx + 44, cy + 240, cw - 88, 42);
            DrawButton(g, qmRect, "Quit to Menu", Color.FromArgb(192, 82, 66), Color.White, 11f);
            AddHit(qmRect, () => { showGameOverPopup = false; showingStartScreen = true; paused = true; Invalidate(); });
        }

        private Color GetLightColor()
        {
            if (theme == BoardTheme.BROWN) return Color.FromArgb(240, 217, 181);
            if (theme == BoardTheme.GREEN) return Color.FromArgb(238, 238, 210);
            return Color.FromArgb(235, 236, 240);
        }

        private Color GetDarkColor()
        {
            if (theme == BoardTheme.BROWN) return Color.FromArgb(181, 136, 99);
            if (theme == BoardTheme.GREEN) return Color.FromArgb(118, 150, 86);
            return Color.FromArgb(168, 172, 181);
        }

        private string GetPieceSymbol(Piece p)
        {
            bool w = p.Color == PieceColor.WHITE;
            switch (p.Type)
            {
                case PieceType.KING: return w ? "\u2654" : "\u265A";
                case PieceType.QUEEN: return w ? "\u2655" : "\u265B";
                case PieceType.ROOK: return w ? "\u2656" : "\u265C";
                case PieceType.BISHOP: return w ? "\u2657" : "\u265D";
                case PieceType.KNIGHT: return w ? "\u2658" : "\u265E";
                case PieceType.PAWN: return w ? "\u2659" : "\u265F";
                default: return "";
            }
        }

        private void DrawCardLabel(Graphics g, string text, int x, int y)
        {
            using (Font f = new Font("Segoe UI", 9f, FontStyle.Bold))
            using (Brush b = new SolidBrush(Color.FromArgb(154, 154, 154)))
                g.DrawString(text, f, b, x, y);
        }

        private void DrawClockValue(Graphics g, string text, int x, int y, bool active)
        {
            using (Font f = new Font("Segoe UI", 24f, FontStyle.Bold))
            using (Brush b = new SolidBrush(active ? Color.FromArgb(129, 182, 76) : Color.White))
                g.DrawString(text, f, b, x, y);
        }

        private void DrawSectionHeader(Graphics g, Rectangle r, string text)
        {
            FillRoundRect(g, r, Color.FromArgb(30, 28, 26), 6);
            using (Font f = new Font("Segoe UI", 9.5f, FontStyle.Bold))
            using (Brush b = new SolidBrush(Color.FromArgb(200, 198, 195)))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center })
                g.DrawString("  " + text, f, b, r, sf);
        }

        private void DrawButton(Graphics g, Rectangle r, string text, Color bg, Color fg, float fontSize)
        {
            FillRoundRect(g, r, bg, 8);
            using (Font f = new Font("Segoe UI", fontSize, FontStyle.Bold))
            using (Brush b = new SolidBrush(fg))
            using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                g.DrawString(text, f, b, r, sf);
        }

        private void FillRoundRect(Graphics g, Rectangle r, Color c, int radius)
        {
            int d = radius * 2;
            using (GraphicsPath gp = new GraphicsPath())
            {
                gp.AddArc(r.X, r.Y, d, d, 180, 90);
                gp.AddArc(r.Right - d, r.Y, d, d, 270, 90);
                gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
                gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
                gp.CloseFigure();
                using (Brush b = new SolidBrush(c)) g.FillPath(b, gp);
            }
        }

        [STAThread]
        public static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
