@echo off
setlocal
cd /d "%~dp0.."

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\Shatranj Chess"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\app" mkdir "%INSTALL_DIR%\app"

set "CSC="
if exist "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" (
    set "CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
) else if exist "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe" (
    set "CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
)

if not "%CSC%"=="" (
    echo Compiling native Windows executable Shatranj.exe...
    "%CSC%" /nologo /target:winexe /optimize+ /out:"Shatranj.exe" /win32icon:"app\Shatranj.ico" "app\ShatranjWindowsApp.cs"
)

copy /Y "Shatranj.exe" "%INSTALL_DIR%\Shatranj.exe" >nul
copy /Y "Shatranj-Chess.jar" "%INSTALL_DIR%\Shatranj-Chess.jar" >nul
copy /Y "app\Shatranj.ico" "%INSTALL_DIR%\app\Shatranj.ico" >nul
copy /Y "app\Shatranj_Desktop.hta" "%INSTALL_DIR%\app\Shatranj_Desktop.hta" >nul
copy /Y "app\ShatranjWindowsApp.cs" "%INSTALL_DIR%\app\ShatranjWindowsApp.cs" >nul

set "VBS=%TEMP%\create_shatranj_shortcuts.vbs"
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sDesktop = oWS.SpecialFolders^("Desktop"^)
echo Set oLink = oWS.CreateShortcut^(sDesktop ^& "\Shatranj Chess.lnk"^)
echo oLink.TargetPath = "%INSTALL_DIR%\Shatranj.exe"
echo oLink.WorkingDirectory = "%INSTALL_DIR%"
echo oLink.Description = "Shatranj Chess by Group 1"
echo oLink.IconLocation = "%INSTALL_DIR%\app\Shatranj.ico"
echo oLink.Save
echo sStartMenu = oWS.SpecialFolders^("Programs"^)
echo Set oLink2 = oWS.CreateShortcut^(sStartMenu ^& "\Shatranj Chess.lnk"^)
echo oLink2.TargetPath = "%INSTALL_DIR%\Shatranj.exe"
echo oLink2.WorkingDirectory = "%INSTALL_DIR%"
echo oLink2.Description = "Shatranj Chess by Group 1"
echo oLink2.IconLocation = "%INSTALL_DIR%\app\Shatranj.ico"
echo oLink2.Save
) > "%VBS%"
cscript //nologo "%VBS%"
del /F /Q "%VBS%" >nul 2>&1

start "" "%INSTALL_DIR%\Shatranj.exe"
exit /b 0
