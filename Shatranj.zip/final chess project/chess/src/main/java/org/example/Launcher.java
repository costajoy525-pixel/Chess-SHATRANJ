package org.example;

import java.lang.reflect.Method;

/**
 * Universal entry-point launcher for Windows .exe and standalone fat-JAR execution.
 *
 * 1. Bypasses the Java 11+ module-path check that causes Main (which extends
 *    javafx.application.Application) to fail with "JavaFX runtime components are missing"
 *    when packaged into a fat JAR or Windows .exe wrapper.
 * 2. Automatically launches the JavaFX UI (org.example.Main) if JavaFX runtime libraries
 *    are present, or seamlessly falls back to UniversalSwingChess (built-in Java Desktop UI
 *    using the exact same GameSession, Board, MoveGenerator, and Algorithms engine classes)
 *    so the JAR/EXE runs on ANY Windows PC with any standard Java installation.
 */
public class Launcher {
    public static void main(String[] args) {
        try {
            Class.forName("javafx.application.Application");
            Class.forName("javafx.fxml.FXMLLoader");
            Class<?> mainClass = Class.forName("org.example.Main");
            Method mainMethod = mainClass.getMethod("main", String[].class);
            mainMethod.invoke(null, (Object) args);
        } catch (Throwable t) {
            UniversalSwingChess.launch(args);
        }
    }
}
