package org.example;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/**
 * Universal zero-dependency Java Desktop UI for Shatranj Chess.
 * Uses the exact same GameSession, Board, MoveGenerator, Algorithms, Engine, Move, and Piece
 * classes as ChessController, ensuring 100% identical gameplay and visual styling on any
 * Windows PC even when external JavaFX native DLLs/JARs are not installed.
 */
public class UniversalSwingChess extends JFrame {

    public enum BoardTheme { NEUTRAL, BROWN, GREEN }

    private final GameSession session = new GameSession();

    private int selectedRow = -1;
    private int selectedCol = -1;
    private boolean botThinking = false;
    private boolean paused = false;
    private boolean popupShown = false;
    private boolean showingStartScreen = true;
    private boolean drawerOpen = false;
    private boolean gameOverVisible = false;

    private boolean premoveEnabled = false;
    private int premoveFromRow = -1;
    private int premoveFromCol = -1;
    private int premoveToRow = -1;
    private int premoveToCol = -1;

    private int lastMovedPieceRow = -1;
    private int lastMovedPieceCol = -1;

    private BoardTheme theme = BoardTheme.NEUTRAL;
    private boolean boardFlipped = false;

    private boolean modeExpanded = false;
    private boolean gameExpanded = false;
    private boolean difficultyExpanded = false;
    private boolean themeExpanded = false;
    private boolean timeExpanded = false;

    private String popupTitleText = "CHECKMATE";
    private String popupMessageText = "White wins!";
    private String popupTimeText = "Time used — White: 00:00   Black: 00:00";

    private final JLayeredPane layeredPane = new JLayeredPane();
    private final JPanel mainContentPanel = new JPanel(new BorderLayout());
    private final BoardPanel boardPanel = new BoardPanel();

    private JButton premoveToggleBtn;
    private JLabel blackClockLabel;
    private JLabel whiteClockLabel;
    private JLabel whiteCapturedLabel;
    private JLabel blackCapturedLabel;
    private JButton playAsWhiteBtn;
    private JButton playAsBlackBtn;
    private JButton undoBtn;
    private JPanel movesListPanel;
    private JLabel statusLabel;

    private JPanel startScreenOverlay;
    private JButton continueBtn;
    private JPanel drawerOverlay;
    private JPanel gameOverOverlay;
    private JLabel popupTitleLbl;
    private JLabel popupMessageLbl;
    private JLabel popupTimeLbl;

    private Timer clockTimer;

    private static final Color BG_DARK = Color.decode("#1e1e1e");
    private static final Color PANEL_DARK = Color.decode("#262421");
    private static final Color BOARD_FRAME = Color.decode("#312e2b");
    private static final Color ACCENT_GREEN = Color.decode("#81b64c");
    private static final Color ACCENT_GOLD = Color.decode("#f5c542");
    private static final Color BTN_BASE = Color.decode("#3a3a3a");
    private static final Color BTN_DANGER = Color.decode("#c05242");
    private static final Color BTN_WARN = Color.decode("#d17c4a");
    private static final Color SELECTED_COLOR = Color.decode("#F7D774");
    private static final Color PREMOVE_COLOR = Color.decode("#C4B5E0");

    public static void launch(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(() -> {
            UniversalSwingChess app = new UniversalSwingChess();
            app.setVisible(true);
        });
    }

    public UniversalSwingChess() {
        super("Chess - Shatranj by Group 1");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 820);
        setMinimumSize(new Dimension(920, 720));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);

        setContentPane(layeredPane);
        layeredPane.setBackground(BG_DARK);
        layeredPane.setOpaque(true);

        buildMainContent();
        buildStartScreenOverlay();
        buildGameOverOverlay();

        layeredPane.add(mainContentPanel, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(startScreenOverlay, JLayeredPane.PALETTE_LAYER);
        layeredPane.add(gameOverOverlay, JLayeredPane.MODAL_LAYER);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                layoutLayers();
            }
        });

        startClock();
        showStartScreen();
        layoutLayers();
    }

    private void layoutLayers() {
        int w = layeredPane.getWidth();
        int h = layeredPane.getHeight();
        if (w <= 0 || h <= 0) {
            w = getWidth();
            h = getHeight();
        }
        mainContentPanel.setBounds(0, 0, w, h);
        startScreenOverlay.setBounds(0, 0, w, h);
        gameOverOverlay.setBounds(0, 0, w, h);
        if (drawerOverlay != null) {
            drawerOverlay.setBounds(0, 0, w, h);
        }
        layeredPane.revalidate();
        layeredPane.repaint();
    }

    private void buildMainContent() {
        mainContentPanel.setBackground(BG_DARK);
        mainContentPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Top Bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(0, 0, 12, 0));

        JButton hamburgerBtn = createStyledButton("\u2630", PANEL_DARK, Color.WHITE, 20);
        hamburgerBtn.setPreferredSize(new Dimension(52, 40));
        hamburgerBtn.addActionListener(e -> openDrawer());

        JLabel titleLbl = new JLabel("Shatranj");
        titleLbl.setForeground(Color.decode("#e8e8e8"));
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));

        JLabel subLbl = new JLabel("by Group 1");
        subLbl.setForeground(ACCENT_GREEN);
        subLbl.setFont(new Font("Segoe UI", Font.ITALIC, 14));

        topBar.add(hamburgerBtn);
        topBar.add(titleLbl);
        topBar.add(subLbl);
        mainContentPanel.add(topBar, BorderLayout.NORTH);

        // Center Area (Board + Right Sidebar)
        JPanel centerArea = new JPanel(new GridBagLayout());
        centerArea.setOpaque(false);

        JPanel boardContainer = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BOARD_FRAME);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose();
            }
        };
        boardContainer.setOpaque(false);
        boardContainer.setPreferredSize(new Dimension(664, 664));
        boardContainer.setMinimumSize(new Dimension(664, 664));
        boardContainer.setMaximumSize(new Dimension(664, 664));
        boardPanel.setPreferredSize(new Dimension(640, 640));
        boardPanel.setMinimumSize(new Dimension(640, 640));
        boardContainer.add(boardPanel);

        JPanel sidebar = buildSidebar();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 0, 24);
        centerArea.add(boardContainer, gbc);

        gbc.gridx = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        gbc.fill = GridBagConstraints.VERTICAL;
        centerArea.add(sidebar, gbc);

        mainContentPanel.add(centerArea, BorderLayout.CENTER);

        // Bottom Status Bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomBar.setOpaque(false);
        bottomBar.setBorder(new EmptyBorder(12, 0, 0, 0));
        statusLabel = new JLabel("White to move");
        statusLabel.setForeground(Color.decode("#e8e8e8"));
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        bottomBar.add(statusLabel);
        mainContentPanel.add(bottomBar, BorderLayout.SOUTH);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setOpaque(false);
        sidebar.setPreferredSize(new Dimension(230, 664));

        premoveToggleBtn = createStyledButton("Premove: OFF", BTN_BASE, Color.WHITE, 14);
        premoveToggleBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        premoveToggleBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        premoveToggleBtn.addActionListener(e -> {
            if (!showingStartScreen && !session.getMoveNotation().isEmpty()) return;
            premoveEnabled = !premoveEnabled;
            updatePremoveToggleStyle();
        });
        sidebar.add(premoveToggleBtn);
        sidebar.add(Box.createVerticalStrut(10));

        // Black clock card
        JPanel blackCard = createCardPanel();
        JLabel blackTitle = createSectionLabel("BLACK");
        blackClockLabel = new JLabel("03:00");
        blackClockLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        blackClockLabel.setForeground(Color.WHITE);
        blackCard.add(blackTitle);
        blackCard.add(Box.createVerticalStrut(4));
        blackCard.add(blackClockLabel);
        sidebar.add(blackCard);
        sidebar.add(Box.createVerticalStrut(10));

        // White clock card
        JPanel whiteCard = createCardPanel();
        JLabel whiteTitle = createSectionLabel("WHITE");
        whiteClockLabel = new JLabel("03:00");
        whiteClockLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        whiteClockLabel.setForeground(ACCENT_GREEN);
        whiteCard.add(whiteTitle);
        whiteCard.add(Box.createVerticalStrut(4));
        whiteCard.add(whiteClockLabel);
        sidebar.add(whiteCard);
        sidebar.add(Box.createVerticalStrut(10));

        // Captured pieces card
        JPanel capCard = createCardPanel();
        capCard.add(createSectionLabel("CAPTURED PIECES"));
        capCard.add(Box.createVerticalStrut(4));
        JLabel wcTitle = new JLabel("White captured:");
        wcTitle.setForeground(Color.decode("#e8e8e8"));
        wcTitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        whiteCapturedLabel = new JLabel("None");
        whiteCapturedLabel.setForeground(Color.WHITE);
        whiteCapturedLabel.setFont(pieceFont(16));
        JLabel bcTitle = new JLabel("Black captured:");
        bcTitle.setForeground(Color.decode("#e8e8e8"));
        bcTitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        blackCapturedLabel = new JLabel("None");
        blackCapturedLabel.setForeground(Color.WHITE);
        blackCapturedLabel.setFont(pieceFont(16));
        capCard.add(wcTitle);
        capCard.add(whiteCapturedLabel);
        capCard.add(Box.createVerticalStrut(6));
        capCard.add(bcTitle);
        capCard.add(blackCapturedLabel);
        sidebar.add(capCard);
        sidebar.add(Box.createVerticalStrut(10));

        // Play As card
        JPanel playAsCard = createCardPanel();
        playAsCard.add(createSectionLabel("PLAY AS"));
        playAsCard.add(Box.createVerticalStrut(6));
        JPanel sideRow = new JPanel(new GridLayout(1, 2, 6, 0));
        sideRow.setOpaque(false);
        sideRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        sideRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        playAsWhiteBtn = createStyledButton("White", BTN_BASE, Color.WHITE, 13);
        playAsBlackBtn = createStyledButton("Black", BTN_BASE, Color.WHITE, 13);
        playAsWhiteBtn.addActionListener(e -> startNewGame(Piece.Color.WHITE));
        playAsBlackBtn.addActionListener(e -> startNewGame(Piece.Color.BLACK));
        sideRow.add(playAsWhiteBtn);
        sideRow.add(playAsBlackBtn);
        playAsCard.add(sideRow);
        sidebar.add(playAsCard);
        sidebar.add(Box.createVerticalStrut(10));

        // Undo button
        undoBtn = createStyledButton("Undo Last Move", BTN_BASE, Color.decode("#6a6a6a"), 14);
        undoBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        undoBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        undoBtn.addActionListener(e -> undoLastTwoMoves());
        sidebar.add(undoBtn);
        sidebar.add(Box.createVerticalStrut(10));

        // Moves card
        JPanel movesCard = createCardPanel();
        movesCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        movesCard.add(createSectionLabel("MOVES"));
        movesCard.add(Box.createVerticalStrut(6));
        movesListPanel = new JPanel();
        movesListPanel.setLayout(new BoxLayout(movesListPanel, BoxLayout.Y_AXIS));
        movesListPanel.setBackground(PANEL_DARK);
        JScrollPane scroll = new JScrollPane(movesListPanel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(PANEL_DARK);
        scroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        movesCard.add(scroll);
        sidebar.add(movesCard);

        return sidebar;
    }

    private void buildStartScreenOverlay() {
        startScreenOverlay = new JPanel(new GridBagLayout());
        startScreenOverlay.setBackground(BG_DARK);
        startScreenOverlay.addMouseListener(new MouseAdapter() {});

        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        row.setOpaque(false);

        JLabel leftKnight = new JLabel("\u2658");
        leftKnight.setFont(pieceFont(220));
        leftKnight.setForeground(PANEL_DARK);

        JPanel centerBox = new JPanel();
        centerBox.setLayout(new BoxLayout(centerBox, BoxLayout.Y_AXIS));
        centerBox.setOpaque(false);
        centerBox.setPreferredSize(new Dimension(420, 360));

        JLabel title = new JLabel("SHATRANJ", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 52));
        title.setForeground(ACCENT_GOLD);

        JLabel sub = new JLabel("by Group 1", SwingConstants.CENTER);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        sub.setFont(new Font("Segoe UI", Font.ITALIC, 20));
        sub.setForeground(ACCENT_GREEN);

        JButton startBtn = createStyledButton("Start Game", ACCENT_GREEN, Color.WHITE, 17);
        startBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        startBtn.setMaximumSize(new Dimension(380, 50));
        startBtn.setPreferredSize(new Dimension(380, 50));
        startBtn.addActionListener(e -> {
            startScreenOverlay.setVisible(false);
            showingStartScreen = false;
            paused = false;
            updatePremoveToggleStyle();
            startNewGame(session.getHumanColor());
        });

        continueBtn = createStyledButton("Continue", BTN_BASE, Color.WHITE, 17);
        continueBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        continueBtn.setMaximumSize(new Dimension(380, 50));
        continueBtn.setPreferredSize(new Dimension(380, 50));
        continueBtn.addActionListener(e -> {
            if (!continueBtn.isEnabled()) return;
            startScreenOverlay.setVisible(false);
            showingStartScreen = false;
            paused = false;
            refreshAll();
        });

        JButton quitBtn = createStyledButton("Quit", BTN_DANGER, Color.WHITE, 17);
        quitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        quitBtn.setMaximumSize(new Dimension(380, 50));
        quitBtn.setPreferredSize(new Dimension(380, 50));
        quitBtn.addActionListener(e -> System.exit(0));

        centerBox.add(Box.createVerticalGlue());
        centerBox.add(title);
        centerBox.add(Box.createVerticalStrut(6));
        centerBox.add(sub);
        centerBox.add(Box.createVerticalStrut(30));
        centerBox.add(startBtn);
        centerBox.add(Box.createVerticalStrut(14));
        centerBox.add(continueBtn);
        centerBox.add(Box.createVerticalStrut(14));
        centerBox.add(quitBtn);
        centerBox.add(Box.createVerticalGlue());

        JLabel rightKnight = new JLabel("\u265E");
        rightKnight.setFont(pieceFont(220));
        rightKnight.setForeground(PANEL_DARK);

        row.add(leftKnight);
        row.add(centerBox);
        row.add(rightKnight);
        startScreenOverlay.add(row);
    }

    private void buildGameOverOverlay() {
        gameOverOverlay = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 165));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gameOverOverlay.setOpaque(false);
        gameOverOverlay.setVisible(false);
        gameOverOverlay.addMouseListener(new MouseAdapter() {});

        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BOARD_FRAME);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(32, 48, 32, 48));
        card.setPreferredSize(new Dimension(380, 340));

        popupTitleLbl = new JLabel("CHECKMATE", SwingConstants.CENTER);
        popupTitleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        popupTitleLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        popupTitleLbl.setForeground(ACCENT_GOLD);

        popupMessageLbl = new JLabel("White wins!", SwingConstants.CENTER);
        popupMessageLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        popupMessageLbl.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        popupMessageLbl.setForeground(Color.decode("#e8e8e8"));

        popupTimeLbl = new JLabel("Time used — White: 00:00   Black: 00:00", SwingConstants.CENTER);
        popupTimeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        popupTimeLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        popupTimeLbl.setForeground(Color.decode("#9a9a9a"));

        JButton newGameBtn = createStyledButton("New Game", ACCENT_GREEN, Color.WHITE, 15);
        newGameBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        newGameBtn.setMaximumSize(new Dimension(280, 44));
        newGameBtn.addActionListener(e -> {
            gameOverOverlay.setVisible(false);
            resetGame();
        });

        JButton viewBoardBtn = createStyledButton("View Board", BTN_BASE, Color.decode("#e0e0e0"), 15);
        viewBoardBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewBoardBtn.setMaximumSize(new Dimension(280, 44));
        viewBoardBtn.addActionListener(e -> gameOverOverlay.setVisible(false));

        JButton quitMenuBtn = createStyledButton("Quit to Menu", BTN_DANGER, Color.WHITE, 15);
        quitMenuBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        quitMenuBtn.setMaximumSize(new Dimension(280, 44));
        quitMenuBtn.addActionListener(e -> {
            gameOverOverlay.setVisible(false);
            paused = true;
            showStartScreen();
        });

        card.add(popupTitleLbl);
        card.add(Box.createVerticalStrut(10));
        card.add(popupMessageLbl);
        card.add(Box.createVerticalStrut(8));
        card.add(popupTimeLbl);
        card.add(Box.createVerticalStrut(20));
        card.add(newGameBtn);
        card.add(Box.createVerticalStrut(10));
        card.add(viewBoardBtn);
        card.add(Box.createVerticalStrut(10));
        card.add(quitMenuBtn);

        gameOverOverlay.add(card);
    }

    private void openDrawer() {
        if (drawerOverlay != null || showingStartScreen) return;
        drawerOverlay = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 128));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        drawerOverlay.setOpaque(false);
        drawerOverlay.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getX() > 320) closeDrawer();
            }
        });

        JPanel drawer = new JPanel();
        drawer.setLayout(new BoxLayout(drawer, BoxLayout.Y_AXIS));
        drawer.setBackground(PANEL_DARK);
        drawer.setBorder(new EmptyBorder(24, 24, 24, 24));
        drawer.setPreferredSize(new Dimension(320, getHeight()));

        // GAME MODE
        drawer.add(createCollapsibleHeader("GAME MODE", modeExpanded, () -> {
            modeExpanded = !modeExpanded;
            closeDrawer();
            openDrawer();
        }));
        drawer.add(Box.createVerticalStrut(8));
        if (modeExpanded) {
            JButton botBtn = createStyledButton("Player vs Bot",
                    session.getMode() == GameSession.Mode.VS_BOT ? ACCENT_GREEN : BTN_BASE, Color.WHITE, 14);
            botBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            botBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            botBtn.addActionListener(e -> {
                session.startNewGame(GameSession.Mode.VS_BOT, session.getDifficulty(), session.getHumanColor(), 180);
                difficultyExpanded = true;
                closeDrawer();
                openDrawer();
            });
            drawer.add(botBtn);
            drawer.add(Box.createVerticalStrut(6));

            if (session.getMode() == GameSession.Mode.VS_BOT && difficultyExpanded) {
                JPanel diffRow = new JPanel(new GridLayout(1, 3, 6, 0));
                diffRow.setOpaque(false);
                diffRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
                diffRow.setAlignmentX(Component.LEFT_ALIGNMENT);
                diffRow.add(createDiffBtn("Easy", GameSession.Difficulty.EASY));
                diffRow.add(createDiffBtn("Medium", GameSession.Difficulty.MEDIUM));
                diffRow.add(createDiffBtn("Hard", GameSession.Difficulty.HARD));
                drawer.add(diffRow);
                drawer.add(Box.createVerticalStrut(6));
            }

            JButton pvpBtn = createStyledButton("Player vs Player",
                    session.getMode() == GameSession.Mode.VS_PLAYER ? ACCENT_GREEN : BTN_BASE, Color.WHITE, 14);
            pvpBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            pvpBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            pvpBtn.addActionListener(e -> {
                session.startNewGame(GameSession.Mode.VS_PLAYER, session.getDifficulty(), session.getHumanColor(), 180);
                difficultyExpanded = false;
                closeDrawer();
                resetGame();
            });
            drawer.add(pvpBtn);
            drawer.add(Box.createVerticalStrut(10));
        }

        // GAME
        drawer.add(createCollapsibleHeader("GAME", gameExpanded, () -> {
            gameExpanded = !gameExpanded;
            closeDrawer();
            openDrawer();
        }));
        drawer.add(Box.createVerticalStrut(8));
        if (gameExpanded) {
            JButton ngBtn = createStyledButton("New Game", BTN_BASE, Color.WHITE, 14);
            ngBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            ngBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            ngBtn.addActionListener(e -> { closeDrawer(); resetGame(); });

            JButton pauseBtn = createStyledButton(paused ? "Resume" : "Pause", BTN_BASE, Color.WHITE, 14);
            pauseBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            pauseBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            pauseBtn.addActionListener(e -> { paused = !paused; closeDrawer(); updateStatus(); updateUndoButton(); });

            JButton qmBtn = createStyledButton("Quit to Menu", BTN_DANGER, Color.WHITE, 14);
            qmBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            qmBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            qmBtn.addActionListener(e -> { closeDrawer(); paused = true; showStartScreen(); });

            drawer.add(ngBtn);
            drawer.add(Box.createVerticalStrut(6));
            drawer.add(pauseBtn);
            drawer.add(Box.createVerticalStrut(6));
            drawer.add(qmBtn);
            drawer.add(Box.createVerticalStrut(10));
        }

        // TIME CONTROL
        drawer.add(createCollapsibleHeader("TIME CONTROL", timeExpanded, () -> {
            timeExpanded = !timeExpanded;
            closeDrawer();
            openDrawer();
        }));
        drawer.add(Box.createVerticalStrut(8));
        if (timeExpanded) {
            JPanel r1 = new JPanel(new GridLayout(1, 2, 6, 0));
            r1.setOpaque(false);
            r1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
            r1.setAlignmentX(Component.LEFT_ALIGNMENT);
            r1.add(createTimeBtn("Bullet", 60));
            r1.add(createTimeBtn("Blitz", 180));

            JPanel r2 = new JPanel(new GridLayout(1, 2, 6, 0));
            r2.setOpaque(false);
            r2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
            r2.setAlignmentX(Component.LEFT_ALIGNMENT);
            r2.add(createTimeBtn("Rapid", 600));
            r2.add(createTimeBtn("Classic", 1800));

            drawer.add(r1);
            drawer.add(Box.createVerticalStrut(6));
            drawer.add(r2);
            drawer.add(Box.createVerticalStrut(10));
        }

        // THEME
        drawer.add(createCollapsibleHeader("THEME", themeExpanded, () -> {
            themeExpanded = !themeExpanded;
            closeDrawer();
            openDrawer();
        }));
        drawer.add(Box.createVerticalStrut(8));
        if (themeExpanded) {
            JPanel tr = new JPanel(new GridLayout(1, 3, 6, 0));
            tr.setOpaque(false);
            tr.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
            tr.setAlignmentX(Component.LEFT_ALIGNMENT);
            tr.add(createThemeBtn("Neutral", BoardTheme.NEUTRAL));
            tr.add(createThemeBtn("Brown", BoardTheme.BROWN));
            tr.add(createThemeBtn("Green", BoardTheme.GREEN));
            drawer.add(tr);
            drawer.add(Box.createVerticalStrut(10));
        }

        JButton closeBtn = createStyledButton("Close", BTN_BASE, Color.WHITE, 14);
        closeBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        closeBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        closeBtn.addActionListener(e -> closeDrawer());
        drawer.add(closeBtn);

        drawerOverlay.add(drawer, BorderLayout.WEST);
        layeredPane.add(drawerOverlay, JLayeredPane.POPUP_LAYER);
        layoutLayers();
    }

    private void closeDrawer() {
        if (drawerOverlay == null) return;
        layeredPane.remove(drawerOverlay);
        drawerOverlay = null;
        layeredPane.revalidate();
        layeredPane.repaint();
    }

    private JButton createCollapsibleHeader(String title, boolean expanded, Runnable onClick) {
        JButton b = createStyledButton((expanded ? "\u25BC  " : "\u25B6  ") + title,
                Color.decode("#1e1c1a"), Color.decode("#c8c6c3"), 12);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.addActionListener(e -> onClick.run());
        return b;
    }

    private JButton createDiffBtn(String text, GameSession.Difficulty d) {
        boolean active = session.getDifficulty() == d;
        JButton b = createStyledButton(text, active ? ACCENT_GREEN : BTN_BASE, Color.WHITE, 11);
        b.addActionListener(e -> {
            session.startNewGame(session.getMode(), d, session.getHumanColor(), 180);
            closeDrawer();
            resetGame();
        });
        return b;
    }

    private JButton createTimeBtn(String text, int seconds) {
        boolean active = session.getStartingTime() == seconds;
        JButton b = createStyledButton(text, active ? ACCENT_GREEN : BTN_BASE, Color.WHITE, 11);
        b.addActionListener(e -> {
            session.startNewGame(session.getMode(), session.getDifficulty(), session.getHumanColor(), seconds);
            closeDrawer();
            resetGame();
        });
        return b;
    }

    private JButton createThemeBtn(String text, BoardTheme t) {
        boolean active = theme == t;
        JButton b = createStyledButton(text, active ? ACCENT_GREEN : BTN_BASE, Color.WHITE, 11);
        b.addActionListener(e -> {
            theme = t;
            closeDrawer();
            boardPanel.repaint();
        });
        return b;
    }

    private void startClock() {
        clockTimer = new Timer(1000, e -> {
            if (paused || showingStartScreen) return;
            session.tickClock();
            updateClocks();
            if (session.isGameOver() && !popupShown) {
                popupShown = true;
                showGameOverCard();
            }
        });
        clockTimer.start();
    }

    private void showStartScreen() {
        if (drawerOverlay != null) closeDrawer();
        showingStartScreen = true;
        paused = true;
        popupShown = false;
        updatePremoveToggleStyle();
        continueBtn.setEnabled(session.isGameOver() || !session.getMoveNotation().isEmpty());
        startScreenOverlay.setVisible(true);
    }

    private void startNewGame(Piece.Color color) {
        gameOverOverlay.setVisible(false);
        int startSecs = session.getStartingTime() > 0 ? session.getStartingTime() : 180;
        session.startNewGame(session.getMode(), session.getDifficulty(), color, startSecs);
        boardFlipped = (session.getMode() == GameSession.Mode.VS_BOT) && (color == Piece.Color.BLACK);
        selectedRow = -1;
        selectedCol = -1;
        lastMovedPieceRow = -1;
        lastMovedPieceCol = -1;
        clearPremove();
        botThinking = false;
        paused = false;
        popupShown = false;
        refreshAll();

        if (session.getMode() == GameSession.Mode.VS_BOT && session.getBoard().getSideToMove() != color) {
            startBotTurn();
        }
    }

    private void resetGame() {
        startNewGame(session.getHumanColor());
    }

    private void undoLastTwoMoves() {
        if (botThinking || session.isGameOver() || paused || session.getMoveNotation().size() < 2) return;
        session.undoLastTwoMoves();
        selectedRow = -1;
        selectedCol = -1;
        lastMovedPieceRow = -1;
        lastMovedPieceCol = -1;
        clearPremove();
        refreshAll();
    }

    private void clearPremove() {
        premoveFromRow = -1;
        premoveFromCol = -1;
        premoveToRow = -1;
        premoveToCol = -1;
    }

    private void refreshAll() {
        boardPanel.repaint();
        updateStatus();
        updateClocks();
        updateUndoButton();
        updateMovesList();
        updateCapturedPieces();
        updateSideButtons();
        updatePremoveToggleStyle();
    }

    private void updatePremoveToggleStyle() {
        if (premoveToggleBtn == null) return;
        boolean locked = !showingStartScreen && !session.getMoveNotation().isEmpty();
        premoveToggleBtn.setEnabled(!locked);
        premoveToggleBtn.setText("Premove: " + (premoveEnabled ? "ON" : "OFF"));
        if (locked) {
            premoveToggleBtn.setBackground(Color.decode("#2a2a2a"));
        } else {
            premoveToggleBtn.setBackground(premoveEnabled ? ACCENT_GREEN : BTN_BASE);
        }
    }

    private void updateClocks() {
        if (whiteClockLabel != null) {
            whiteClockLabel.setText(formatTime(session.getWhiteTime()));
            whiteClockLabel.setForeground(
                    session.getBoard().getSideToMove() == Piece.Color.WHITE && !session.isGameOver()
                            ? ACCENT_GREEN : Color.WHITE);
        }
        if (blackClockLabel != null) {
            blackClockLabel.setText(formatTime(session.getBlackTime()));
            blackClockLabel.setForeground(
                    session.getBoard().getSideToMove() == Piece.Color.BLACK && !session.isGameOver()
                            ? ACCENT_GREEN : Color.WHITE);
        }
    }

    private void updateCapturedPieces() {
        if (whiteCapturedLabel == null || blackCapturedLabel == null) return;
        String wc = session.getCapturedPieces(Piece.Color.WHITE);
        String bc = session.getCapturedPieces(Piece.Color.BLACK);
        whiteCapturedLabel.setText(wc.isEmpty() ? "None" : wc);
        blackCapturedLabel.setText(bc.isEmpty() ? "None" : bc);
    }

    private void updateUndoButton() {
        if (undoBtn == null) return;
        boolean enabled = !botThinking && !session.isGameOver() && !paused && !showingStartScreen
                && session.getMoveNotation().size() >= 2;
        undoBtn.setEnabled(enabled);
        undoBtn.setBackground(enabled ? BTN_WARN : BTN_BASE);
        undoBtn.setForeground(enabled ? Color.WHITE : Color.decode("#6a6a6a"));
    }

    private void updateMovesList() {
        if (movesListPanel == null) return;
        movesListPanel.removeAll();
        List<String> notation = session.getMoveNotation();
        for (int i = 0; i < notation.size(); i += 2) {
            String line = (i / 2 + 1) + ". " + notation.get(i);
            if (i + 1 < notation.size()) line += "   " + notation.get(i + 1);
            JLabel l = new JLabel(line);
            l.setForeground(Color.decode("#9a9a9a"));
            l.setFont(new Font("Segoe UI", Font.BOLD, 12));
            movesListPanel.add(l);
        }
        movesListPanel.revalidate();
        movesListPanel.repaint();
    }

    private void updateSideButtons() {
        if (playAsWhiteBtn == null || playAsBlackBtn == null) return;
        boolean pvp = session.getMode() == GameSession.Mode.VS_PLAYER;
        playAsWhiteBtn.setEnabled(!pvp);
        playAsBlackBtn.setEnabled(!pvp);
    }

    private void updateStatus() {
        if (statusLabel == null || session.isGameOver()) return;
        if (paused) {
            statusLabel.setText("Paused");
            return;
        }
        if (botThinking) {
            statusLabel.setText(premoveFromRow != -1 && premoveToRow != -1
                    ? "Bot is thinking... (Premove queued)" : "Bot is thinking...");
        } else {
            Piece.Color turn = session.getBoard().getSideToMove();
            String check = session.getBoard().isInCheck(turn) ? " (CHECK!)" : "";
            statusLabel.setText((turn == Piece.Color.WHITE ? "White" : "Black") + " to move" + check);
        }
    }

    private void showGameOverCard() {
        if (session.getMoveNotation().isEmpty()) return;
        String title, message;
        if (session.getWhiteTime() == 0) {
            title = "TIME OUT";
            message = "Black wins on time!";
        } else if (session.getBlackTime() == 0) {
            title = "TIME OUT";
            message = "White wins on time!";
        } else if (session.getBoard().isInCheck(session.getBoard().getSideToMove())) {
            Piece.Color winner = (session.getBoard().getSideToMove() == Piece.Color.WHITE)
                    ? Piece.Color.BLACK : Piece.Color.WHITE;
            title = "CHECKMATE";
            message = (winner == Piece.Color.WHITE ? "White" : "Black") + " wins!";
        } else {
            title = "STALEMATE";
            message = "It's a draw.";
        }
        popupTitleLbl.setText(title);
        popupMessageLbl.setText(message);
        popupTimeLbl.setText("Time used — White: " + formatTime(session.getStartingTime() - session.getWhiteTime())
                + "   Black: " + formatTime(session.getStartingTime() - session.getBlackTime()));
        gameOverOverlay.setVisible(true);
    }

    private String formatTime(int seconds) {
        return String.format("%02d:%02d", Math.max(0, seconds) / 60, Math.max(0, seconds) % 60);
    }

    private int displayRow(int boardRow) { return boardFlipped ? 7 - boardRow : boardRow; }
    private int displayCol(int boardCol) { return boardFlipped ? 7 - boardCol : boardCol; }

    private void onCellClicked(int dRow, int dCol) {
        if (showingStartScreen || session.isGameOver() || paused || drawerOverlay != null) return;
        int row = boardFlipped ? 7 - dRow : dRow;
        int col = boardFlipped ? 7 - dCol : dCol;

        boolean playerTurn = (session.getMode() == GameSession.Mode.VS_PLAYER)
                || (session.getBoard().getSideToMove() == session.getHumanColor());

        if (!playerTurn && !premoveEnabled) return;
        if (!playerTurn && premoveEnabled) {
            handlePremoveClick(row, col);
            return;
        }
        if (botThinking) return;

        Piece clicked = session.getBoard().getPiece(row, col);
        Piece.Color turn = session.getBoard().getSideToMove();

        if (selectedRow == -1) {
            if (clicked != null && clicked.getColor() == turn) {
                selectedRow = row;
                selectedCol = col;
                boardPanel.repaint();
            }
            return;
        }

        Move chosen = findMove(selectedRow, selectedCol, row, col);
        if (chosen != null) {
            session.makeMove(chosen);
            lastMovedPieceRow = chosen.getToRow();
            lastMovedPieceCol = chosen.getToCol();
            selectedRow = -1;
            selectedCol = -1;
            refreshAll();
            if (session.isGameOver()) {
                showGameOverCard();
                return;
            }
            if (session.getMode() == GameSession.Mode.VS_BOT) startBotTurn();
        } else {
            if (clicked != null && clicked.getColor() == turn) {
                selectedRow = row;
                selectedCol = col;
            } else {
                selectedRow = -1;
                selectedCol = -1;
            }
            boardPanel.repaint();
        }
    }

    private void handlePremoveClick(int row, int col) {
        Piece clicked = session.getBoard().getPiece(row, col);
        if (premoveFromRow == -1) {
            if (clicked != null && clicked.getColor() == session.getHumanColor()) {
                premoveFromRow = row;
                premoveFromCol = col;
                boardPanel.repaint();
            }
            return;
        }
        if (clicked != null && clicked.getColor() == session.getHumanColor()
                && !(row == premoveFromRow && col == premoveFromCol)) {
            premoveFromRow = row;
            premoveFromCol = col;
            premoveToRow = -1;
            premoveToCol = -1;
            boardPanel.repaint();
            return;
        }
        premoveToRow = row;
        premoveToCol = col;
        boardPanel.repaint();
        updateStatus();
    }

    private void startBotTurn() {
        botThinking = true;
        updateStatus();
        updateUndoButton();

        Thread t = new Thread(() -> {
            try {
                Thread.sleep(1000);
                Move botMove = session.getBotMove();
                SwingUtilities.invokeLater(() -> {
                    if (botMove != null) {
                        session.makeMove(botMove);
                        lastMovedPieceRow = botMove.getToRow();
                        lastMovedPieceCol = botMove.getToCol();
                    }
                    botThinking = false;
                    refreshAll();
                    if (session.isGameOver()) {
                        showGameOverCard();
                        return;
                    }
                    if (session.getMode() == GameSession.Mode.VS_BOT
                            && session.getBoard().getSideToMove() == session.getHumanColor()
                            && premoveFromRow != -1) {
                        executePremove();
                    }
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    botThinking = false;
                    refreshAll();
                });
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void executePremove() {
        if (premoveFromRow == -1 || premoveToRow == -1) return;
        Move chosen = findMove(premoveFromRow, premoveFromCol, premoveToRow, premoveToCol);
        clearPremove();
        if (chosen != null) {
            session.makeMove(chosen);
            lastMovedPieceRow = chosen.getToRow();
            lastMovedPieceCol = chosen.getToCol();
            refreshAll();
            if (session.isGameOver()) {
                showGameOverCard();
                return;
            }
            if (session.getMode() == GameSession.Mode.VS_BOT) startBotTurn();
        } else {
            boardPanel.repaint();
        }
    }

    private Move findMove(int fromRow, int fromCol, int toRow, int toCol) {
        List<Move> current = MoveGenerator.generateLegalMoves(session.getBoard());
        Move fallback = null;
        for (Move m : current) {
            if (m.getFromRow() == fromRow && m.getFromCol() == fromCol
                    && m.getToRow() == toRow && m.getToCol() == toCol) {
                if (m.getFlag() == Move.Flag.PROMOTION_QUEEN) return m;
                if (fallback == null) fallback = m;
            }
        }
        return fallback;
    }

    private boolean isLegalDestination(int row, int col) {
        if (selectedRow == -1) return false;
        List<Move> legal = MoveGenerator.generateLegalMoves(session.getBoard());
        for (Move m : legal) {
            if (m.getFromRow() == selectedRow && m.getFromCol() == selectedCol
                    && m.getToRow() == row && m.getToCol() == col) return true;
        }
        return false;
    }

    private Color lightColor() {
        switch (theme) {
            case BROWN: return Color.decode("#F0D9B5");
            case GREEN: return Color.decode("#EEEED2");
            default:    return Color.decode("#EBECF0");
        }
    }

    private Color darkColor() {
        switch (theme) {
            case BROWN: return Color.decode("#B58863");
            case GREEN: return Color.decode("#769656");
            default:    return Color.decode("#A8ACB5");
        }
    }

    private String pieceSymbol(Piece p) {
        boolean white = p.getColor() == Piece.Color.WHITE;
        switch (p.getType()) {
            case KING:   return white ? "\u2654" : "\u265A";
            case QUEEN:  return white ? "\u2655" : "\u265B";
            case ROOK:   return white ? "\u2656" : "\u265C";
            case BISHOP: return white ? "\u2657" : "\u265D";
            case KNIGHT: return white ? "\u2658" : "\u265E";
            case PAWN:   return white ? "\u2659" : "\u265F";
            default:     return "";
        }
    }

    private static Font pieceFont(int size) {
        return new Font("Segoe UI Symbol", Font.PLAIN, size);
    }

    private JPanel createCardPanel() {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PANEL_DARK);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        return p;
    }

    private JLabel createSectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.decode("#9a9a9a"));
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return l;
    }

    private JButton createStyledButton(String text, Color bg, Color fg, int fontSize) {
        JButton b = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setContentAreaFilled(false);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(false);
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private class BoardPanel extends JPanel {
        public BoardPanel() {
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int c = e.getX() / 80;
                    int r = e.getY() / 80;
                    if (r >= 0 && r < 8 && c >= 0 && c < 8) {
                        onCellClicked(r, c);
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int dr = displayRow(r);
                    int dc = displayCol(c);
                    int x = dc * 80;
                    int y = dr * 80;

                    Color bg = ((r + c) % 2 == 0) ? lightColor() : darkColor();
                    if (r == selectedRow && c == selectedCol) bg = SELECTED_COLOR;
                    else if ((r == premoveFromRow && c == premoveFromCol)
                            || (r == premoveToRow && c == premoveToCol)) bg = PREMOVE_COLOR;

                    g2.setColor(bg);
                    g2.fillRect(x, y, 80, 80);

                    if (r == lastMovedPieceRow && c == lastMovedPieceCol) {
                        Stroke old = g2.getStroke();
                        g2.setColor(Color.decode("#888888"));
                        g2.setStroke(new BasicStroke(3f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER,
                                10f, new float[]{8f, 6f}, 0f));
                        g2.drawRect(x + 2, y + 2, 76, 76);
                        g2.setStroke(old);
                    }

                    boolean legal = isLegalDestination(r, c);
                    Piece target = session.getBoard().getPiece(r, c);
                    if (legal && target == null) {
                        g2.setColor(new Color(58, 58, 58, 140));
                        g2.fillOval(x + 32, y + 32, 16, 16);
                    } else if (legal && target != null) {
                        Stroke old = g2.getStroke();
                        g2.setColor(new Color(58, 58, 58, 155));
                        g2.setStroke(new BasicStroke(4f));
                        g2.drawOval(x + 10, y + 10, 60, 60);
                        g2.setStroke(old);
                    }

                    Piece p = session.getBoard().getPiece(r, c);
                    if (p != null) {
                        String sym = pieceSymbol(p);
                        g2.setFont(pieceFont(54));
                        FontMetrics fm = g2.getFontMetrics();
                        int tx = x + (80 - fm.stringWidth(sym)) / 2;
                        int ty = y + ((80 - fm.getHeight()) / 2) + fm.getAscent();
                        g2.setColor(Color.BLACK);
                        g2.drawString(sym, tx, ty);
                    }
                }
            }
            g2.dispose();
        }
    }
}
